<template>
  <div class="header">
    <div class="header-left"></div>
    <div class="header-input"></div>
    <div class="header-right"></div>
    <p>asd</p>
  </div>
</template>

<script>
export default {
  name: 'HomeHeader'
}
</script>
<style lang ="stylus" scoped>
  .header
    height :86px;
</style>
